#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <iostream>
#include <stdio.h>
#include <fstream>
using namespace std;
using namespace cv;
int filestatus(string filepathname){
	fstream file;
	file.open(filepathname);
	if(file){ 
		cout<<"file exist"<<endl;
		return 1;
	}
	return 0;
}

int main(int, char**)
{
 int count = 1;
 string flocname;
 Mat frame;
 VideoCapture cap("/dev/video0");
 if (!cap.isOpened()) {
 cerr << "ERROR! Unable to open camera\n";
 return -1;
 }
 cout << "Start grabbing" << endl;
 cout << "Press space key to take photo" << endl;
 cout << "Press ESC key to terminate" << endl;
 while(1)
 {
 	cap.read(frame);
	if (frame.empty()) {
		cerr << "ERROR! blank frame grabbed\n";
	 	break;
	}
 // show live and wait for a space key with timeout long enough to show images
 	imshow("Live", frame);
	if (waitKey(30)== 32){
		flocname = "dummy"+ to_string(count)+".PNG";
		while(filestatus(flocname) == 1){
			count ++;
			flocname = "dummy"+ to_string(count)+".PNG";
		}
		vector<int> compression_params;
		compression_params.push_back(1);
		compression_params.push_back(9);
		imwrite(flocname,frame,compression_params);
		cout << "Saved Image"<<endl;
	}
	if (waitKey(30)== 27)
		break;
 // the camera will be deinitialized automatically in VideoCapture destructor
 }
return 0;
}

