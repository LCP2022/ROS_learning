#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <stdio.h>
using namespace cv;
using namespace std;

int main(int, char**)
{
 Mat frame;
 //--- INITIALIZE VIDEOCAPTURE
 VideoCapture cap("/dev/video0");
 // check if we succeeded
 if (!cap.isOpened()) {
 cerr << "ERROR! Unable to open camera\n";
 return -1;
 }
 //--- GRAB AND WRITE LOOP
 cout << "Start grabbing" << endl
 << "Press any key to terminate" << endl;
 while(1)
 {
 	cap.read(frame);
 	// check if we succeeded
	 if (frame.empty()) {
	 cerr << "ERROR! blank frame grabbed\n";
	 break;
	 }
 // show live and wait for a key with timeout long enough to show images
 	imshow("Live", frame);
	if (waitKeyEx(30)>=0){
	break;
	}
 }
 // the camera will be deinitialized automatically in VideoCapture destructor
 return 0;
}

