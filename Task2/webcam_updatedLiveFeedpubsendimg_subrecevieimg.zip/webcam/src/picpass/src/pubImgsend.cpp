#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <sstream> // for converting the command line parameter to integer 
#include <iostream>

using namespace std;
using namespace cv;

int main(int argc, char** argv)
{
    ros::init(argc, argv, "image_publisher");
    ros::NodeHandle nh;
    image_transport::ImageTransport it(nh);
    image_transport::Publisher pub = it.advertise("camera/image", 1); 
    sensor_msgs::ImagePtr msg; 

    Mat frame;
    VideoCapture cap("/dev/video0");
    if (!cap.isOpened()) {
    cerr << "ERROR! Unable to open camera\n";
    return -1;
    }
    cout << "Start grabbing" << endl;
    cout << "Press space key to take photo" << endl;
    ros::Rate loop_rate(5);
    while(nh.ok())
    {
        cap.read(frame);
        if (frame.empty()) {
            cerr << "ERROR! blank frame grabbed\n";
            break;
        }
    // show live and wait for a space key with timeout long enough to show images
        imshow("Live", frame);
        if (waitKey(30)== 32){
            msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", frame).toImageMsg();
            pub.publish(msg);
            ros::spinOnce();
            loop_rate.sleep();
            ROS_INFO("Img sended");
            }
    // the camera will be deinitialized automatically in VideoCapture destructor
    }
    
    return 0;
}

