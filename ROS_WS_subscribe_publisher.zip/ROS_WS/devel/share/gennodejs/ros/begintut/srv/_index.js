
"use strict";

let AddTwoInts = require('./AddTwoInts.js')

module.exports = {
  AddTwoInts: AddTwoInts,
};
