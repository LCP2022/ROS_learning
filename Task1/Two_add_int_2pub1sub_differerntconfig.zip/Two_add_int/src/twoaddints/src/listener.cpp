#include "ros/ros.h"
#include "std_msgs/String.h" 
#include <sstream>
#include <cstdlib>


int sum = 0;
int count = 0;
int num =0;
int prevalue =0;
void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
    ROS_INFO("I heard: [%s]", msg->data.c_str());
    num = atoi(msg->data.c_str());
    count++;
    if(count == 2){
        sum = prevalue + num ; 
        ROS_INFO("Sum: [%d]",sum);
        count = 0;
        num =0;
        prevalue = 0;
    }
    else{
        prevalue = num;
    }
}

int main(int argc, char **argv){
    ros::init(argc, argv, "listener");

    ros::NodeHandle n;

    ros::Subscriber sub = n.subscribe("chatter", 1000, chatterCallback);
    ros::spin(); 
    return 0;


}