
"use strict";

let twoaddints = require('./twoaddints.js')

module.exports = {
  twoaddints: twoaddints,
};
